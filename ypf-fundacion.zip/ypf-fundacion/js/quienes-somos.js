/*
 * autors:
 * Santiago Leopardo @sleopardo
 * Fernando Leopardo @fer_leopardo
*/

;(function(window){

	/*
	 * Variables
	*/
	var boxPersonas = $(".consejo-administrativo .info"),

		boxStaff = $(".infoStaff article");

 	/*
	 * Mismo alto para todas las cajas
	*/
	ypf.equalHeight(boxPersonas);

	ypf.equalHeight(boxStaff);


})(window);