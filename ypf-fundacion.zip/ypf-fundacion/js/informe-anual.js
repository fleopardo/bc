/*
 * autors:
 * Santiago Leopardo @sleopardo
 * Fernando Leopardo @fer_leopardo
*/

;(function(window){

	/*
	 * Variables
	*/
	var box = $(".descarga-pdf .box");

	//Mismo alto para las columnas
	ypf.equalHeight(box);


})(window);