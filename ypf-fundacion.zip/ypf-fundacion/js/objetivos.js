/*
 * autors:
 * Santiago Leopardo @sleopardo
 * Fernando Leopardo @fer_leopardo
*/

;(function(window){

	/*
	 * Variables
	*/
	var boxDestacados = $(".modulos article > div");

 	/*
	 * Mismo alto para todas las cajas
	*/
	ypf.equalHeight(boxDestacados);


})(window);