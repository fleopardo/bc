/*
 * autors:
 * Santiago Leopardo @sleopardo
 * Fernando Leopardo @fer_leopardo
*/

;(function(window){
	$('#mycarousel').jcarousel({
        vertical : true,
        scroll : 1,
        auto : 3
    });



})(window);